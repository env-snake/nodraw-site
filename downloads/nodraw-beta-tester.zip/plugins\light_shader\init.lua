-- light_shader для NoDraw: превью static_projected_light (аддон light_shader для GMod) в режиме
-- 3D Lighting Preview — тот же конус, маска (texturename), NearZ/FarZ, вертикальный FOV, орто-пучок,
-- затухание (Flat / Linear / Quadratic с «Full Brightness Distance»), тени.
--
-- Плюс то, чего нет в Hammer: конусы ламп в окнах, бюджет теней GMod (одновременно только 8
-- ламп с тенями — слоты получают ближайшие к игроку) и «посмотреть из лампы».

local SLOTS = 8

local preview = nodraw.setting{ id = "preview", label = "Light the preview", type = "bool", default = true,
    tip = "static_projected_light lamps light the 3D Lighting Preview" }
local cones = nodraw.setting{ id = "cones", label = "Cones", type = "choice", choices = { "Off", "Selected", "All" }, default = "Selected",
    tip = "Draw the light frustum (NearZ to FarZ) of the lamps" }
local budget = nodraw.setting{ id = "budget", label = "Shadow slot check", type = "bool", default = true,
    tip = "GMod draws shadows for 8 projected lights at once, nearest to the player first. Lamps past the 8th near the camera are marked" }
local start_off = nodraw.setting{ id = "start_off", label = "Lamps that start off", type = "choice", choices = { "Hide", "Show" }, default = "Hide",
    tip = "Start Enabled = No: lit only after TurnOn in the game" }
local brightness = nodraw.setting{ id = "brightness", label = "Brightness", type = "number", min = 0.1, max = 4, step = 0.05, default = 1,
    tip = "Editor only: multiplies Light Strength of every lamp in the preview" }

local lamps = {}
local last_status = nil

local function num(v, d)
    local n = tonumber(v)
    if n == nil then return d end
    return n
end

local function clamp(v, a, b)
    if v < a then return a end
    if v > b then return b end
    return v
end

local function color(v)
    local c = {}
    for x in tostring(v or "255 255 255"):gmatch("%S+") do
        c[#c + 1] = tonumber(x) or 255
    end
    return { c[1] or 255, c[2] or 255, c[3] or 255 }
end

-- Оси Source из углов (pitch yaw roll): вперёд, вправо, вверх.
local function axes(a)
    local p, y, r = math.rad(a[1] or a.x or 0), math.rad(a[2] or a.y or 0), math.rad(a[3] or a.z or 0)
    local sp, cp, sy, cy, sr, cr = math.sin(p), math.cos(p), math.sin(y), math.cos(y), math.sin(r), math.cos(r)
    local f = { cp * cy, cp * sy, -sp }
    local rt = { -sr * sp * cy + cr * sy, -sr * sp * sy - cr * cy, -sr * cp }
    local u = { cr * sp * cy + sr * sy, cr * sp * sy - sr * cy, cr * cp }
    return f, rt, u
end

local function push()
    if not preview then
        nodraw.lights.clear()
        return
    end
    local list = {}
    for _, l in ipairs(lamps) do
        if l.enabled or start_off == "Show" then
            list[#list + 1] = {
                pos = l.pos, angles = l.angles, fov = l.fov, vfov = l.vfov, ortho = l.ortho,
                near = l.near, far = l.far, color = l.color, strength = l.strength * brightness,
                falloff = l.falloff, falloff_distance = l.falloff_distance, texture = l.texture,
                shadows = l.shadows,
            }
        end
    end
    nodraw.lights.set(list)
end

local function rebuild()
    lamps = {}
    for _, e in ipairs(nodraw.map.entities("static_projected_light")) do
        if e.origin then
            local k = nodraw.map.keys(e.id)
            local lower = {}
            for key, v in pairs(k) do lower[key:lower()] = v end
            lamps[#lamps + 1] = {
                id = e.id,
                name = e.name or "",
                pos = e.origin,
                angles = e.angles,
                fov = clamp(num(lower.lightfov, 90), 1, 178),
                vfov = num(lower.verticalfov, 0),
                ortho = math.max(num(lower.orthosize, 0), 0),
                near = clamp(num(lower.nearz, 8), 1, 64),
                far = math.max(num(lower.farz, 512), 16),
                color = color(lower.lightcolor),
                strength = clamp(num(lower.lightstrength, 4), 0, 16),
                falloff = clamp(num(lower.falloffmode, 1), 0, 2),
                falloff_distance = math.max(num(lower.falloffdistance, 100), 1),
                texture = lower.texturename or "effects/flashlight001",
                shadows = lower.enableshadows ~= "0",
                enabled = lower.startenabled ~= "0",
            }
        end
    end
    push()
end

nodraw.on("map", rebuild)

nodraw.on("setting", function(id, value)
    if id == "preview" then preview = value
    elseif id == "cones" then cones = value
    elseif id == "budget" then budget = value
    elseif id == "start_off" then start_off = value
    elseif id == "brightness" then brightness = value
    end
    push()
end)

-- Лампы с тенями, до которых достаёт камера, по близости: первые SLOTS получают тени.
local function shadow_order(cam)
    local list = {}
    for _, l in ipairs(lamps) do
        if l.shadows and (l.enabled or start_off == "Show") then
            local d = math.sqrt((l.pos.x - cam.x) ^ 2 + (l.pos.y - cam.y) ^ 2 + (l.pos.z - cam.z) ^ 2)
            if d < l.far + 1024 then
                list[#list + 1] = { lamp = l, d = d }
            end
        end
    end
    table.sort(list, function(a, b) return a.d < b.d end)
    return list
end

local function draw_cone(l, rgb)
    local f, r, u = axes(l.angles)
    local function at(dist, sx, sy)
        local hw, hh
        if l.ortho > 0 then
            hw, hh = l.ortho, l.ortho
        else
            hw = dist * math.tan(math.rad(l.fov) * 0.5)
            hh = dist * math.tan(math.rad(l.vfov > 0 and l.vfov or l.fov) * 0.5)
        end
        return {
            l.pos.x + f[1] * dist + r[1] * hw * sx + u[1] * hh * sy,
            l.pos.y + f[2] * dist + r[2] * hw * sx + u[2] * hh * sy,
            l.pos.z + f[3] * dist + r[3] * hw * sx + u[3] * hh * sy,
        }
    end
    local corners = { { -1, -1 }, { 1, -1 }, { 1, 1 }, { -1, 1 } }
    local near, far = {}, {}
    for i, c in ipairs(corners) do
        near[i] = at(l.near, c[1], c[2])
        far[i] = at(l.far, c[1], c[2])
    end
    for i = 1, 4 do
        local j = i % 4 + 1
        nodraw.draw.line(near[i], near[j], rgb)
        nodraw.draw.line(far[i], far[j], rgb)
        nodraw.draw.line(near[i], far[i], rgb)
    end
end

nodraw.on("frame", function()
    if cones == "Off" and not budget then
        return
    end
    local selected = {}
    for _, id in ipairs(nodraw.selection()) do selected[id] = true end
    local cam = nodraw.camera()
    local no_slot = {}
    if budget then
        local order = shadow_order(cam)
        for i = SLOTS + 1, #order do
            no_slot[order[i].lamp.id] = true
        end
        local text = nil
        if #order > SLOTS then
            text = string.format("%d shadowed lamps reach the camera, GMod gives shadows to the nearest %d", #order, SLOTS)
        end
        if text ~= last_status then
            last_status = text
            if text then nodraw.status(text) end
        end
    end
    for _, l in ipairs(lamps) do
        local show = cones == "All" or (cones == "Selected" and selected[l.id])
        if show then
            local c = l.color
            draw_cone(l, { math.floor(c[1] * 0.8 + 50), math.floor(c[2] * 0.8 + 50), math.floor(c[3] * 0.8 + 50) })
            local label = string.format("%s%s  %g x%g%s", l.name ~= "" and (l.name .. "  ") or "", l.texture, l.fov, l.strength, l.shadows and "" or "  no shadows")
            nodraw.draw.text(l.pos, label)
        end
        if no_slot[l.id] then
            nodraw.draw.text({ l.pos.x, l.pos.y, l.pos.z + 12 }, "no shadow slot (9th+ nearest)")
            draw_cone(l, { 230, 70, 60 })
        end
    end
end)

nodraw.menu("Look through the selected lamp", function()
    local selected = {}
    for _, id in ipairs(nodraw.selection()) do selected[id] = true end
    for _, l in ipairs(lamps) do
        if selected[l.id] then
            nodraw.look(l.pos, l.angles, l.vfov > 0 and l.vfov or l.fov)
            nodraw.status("looking through lamp #" .. l.id)
            return
        end
    end
    nodraw.status("select a static_projected_light first")
end)

nodraw.menu("Lamp report", function()
    local on, shadowed, off = 0, 0, 0
    for _, l in ipairs(lamps) do
        if l.enabled then on = on + 1 else off = off + 1 end
        if l.shadows then shadowed = shadowed + 1 end
    end
    nodraw.status(string.format("%d lamps: %d start on, %d start off, %d cast shadows", #lamps, on, off, shadowed))
end)
