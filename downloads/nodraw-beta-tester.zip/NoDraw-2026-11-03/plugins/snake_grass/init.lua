-- snake_grass для NoDraw: трава как в игре (аддон snake_grass для GMod).
--
-- Как в аддоне: каждая точка травы, которую vbsp раскидал по материалам с %detailtype, даёт
-- пучок травинок. Травинка — сужающаяся к острию полоса из двух сегментов, наклонённая вперёд
-- по pow(t, 2); поворот — из точки vbsp плюс свой на каждую травинку; размер — из спрайта
-- detail.vbsp. Разброс и число травинок — как настройки snake_grass_density / _spread.
-- Строится кусками 512×512 рядом с камерой (как чанки аддона), дальние куски убираются.

local CHUNK = 512
local PER_FRAME = 3
local WIDTH, HEIGHT = 0.2, 0.7
local CURVE = 2.0
local SEGMENTS = 2
local ROOT_SINK = 2
local MATERIAL = "snake/grass/grass_v8_gust"

local densities = { Low = 3, Normal = 6, High = 12 }

-- Настройки (панель Plugins; значения хранит NoDraw).
local enabled = nodraw.setting{ id = "enabled", label = "Grass", type = "bool", default = true,
    tip = "Draw the snake_grass blades instead of the built-in vbsp detail sprites" }
local density = nodraw.setting{ id = "density", label = "Density", type = "choice", choices = { "Low", "Normal", "High" }, default = "Normal",
    tip = "Blades per vbsp grass point: 3 / 6 / 12 (snake_grass_density in the game)" }
local RADIUS = nodraw.setting{ id = "radius", label = "Draw radius", type = "number", min = 1000, max = 8000, step = 250, default = 3500,
    tip = "Grass is built in 512x512 chunks around the camera up to this distance" }
local SPREAD = nodraw.setting{ id = "spread", label = "Spread", type = "number", min = 0, max = 300, step = 5, default = 100,
    tip = "How far the blades of one point scatter (snake_grass_spread in the game)" }

local buckets = {}   -- "cx:cy" -> { props }
local sprites = {}
local built = {}     -- "cx:cy" -> true
local detail_revision = nil

local function golden(i)
    return (i * 0.6180339887498949) % 1
end

local function clear_all()
    for key in pairs(built) do
        nodraw.mesh.clear("chunk_" .. key)
    end
    built = {}
end

-- На картах ShinriTrials (есть shinri_settings) траву рисует плагин shinri_shaders.
local function shinri_map()
    local e = nodraw.map.entities("shinri_settings")
    return e ~= nil and e[1] ~= nil
end

local function collect()
    clear_all()
    buckets = {}
    if shinri_map() then
        return
    end
    sprites = nodraw.map.detail_sprites()
    detail_revision = nodraw.map.details_revision()
    local n = 0
    for i, p in ipairs(nodraw.map.detail_props()) do
        if p.kind ~= 0 then
            p.index = i
            local key = math.floor(p.x / CHUNK) .. ":" .. math.floor(p.y / CHUNK)
            local b = buckets[key]
            if not b then
                b = {}
                buckets[key] = b
            end
            b[#b + 1] = p
            n = n + 1
        end
    end
    nodraw.status(n .. " grass points from the last compile")
end

-- Одна травинка: вершины x, y, z, u, v подряд, индексы треугольников.
local function blade(v, idx, x, y, z, yaw, half, height, id)
    local fx, fy = math.cos(yaw), math.sin(yaw)
    local sx, sy = -fy, fx
    local lean = height * (0.25 + id * 0.45)
    local base = #v // 5
    local function vert(t, side)
        local w = half * (1 - t)
        local f = (t ^ CURVE) * lean
        local k = #v
        v[k + 1] = x + sx * w * side + fx * f
        v[k + 2] = y + sy * w * side + fy * f
        v[k + 3] = z + height * t
        v[k + 4] = 0.5 + 0.5 * side
        v[k + 5] = 1 - t
    end
    -- Пары вершин по высоте (лево, право), острие — одна.
    for s = 0, SEGMENTS - 1 do
        local t = s / SEGMENTS
        vert(t, -1)
        vert(t, 1)
    end
    vert(1, 0)
    for s = 0, SEGMENTS - 2 do
        local a = base + s * 2
        idx[#idx + 1] = a; idx[#idx + 1] = a + 2; idx[#idx + 1] = a + 1
        idx[#idx + 1] = a + 1; idx[#idx + 1] = a + 2; idx[#idx + 1] = a + 3
    end
    local last = base + (SEGMENTS - 1) * 2
    idx[#idx + 1] = last; idx[#idx + 1] = last + 2; idx[#idx + 1] = last + 1
end

local function build(key)
    local props = buckets[key]
    local v, idx = {}, {}
    local count = densities[density] or 6
    for _, p in ipairs(props) do
        local sp = sprites[p.sprite] or { w = 20, h = 40 }
        local scale = (p.scale > 0) and p.scale or 1
        local width, height = sp.w * scale * WIDTH, sp.h * scale * HEIGHT
        for k = 0, count - 1 do
            local a = golden(p.index * 7 + k * 31)
            local b = golden(p.index * 13 + k * 57 + 3)
            local x, y = p.x, p.y
            if k > 0 then
                x = x + (a - 0.5) * SPREAD
                y = y + (b - 0.5) * SPREAD
            end
            local yaw = math.rad(p.yaw + b * 360)
            blade(v, idx, x, y, p.z - ROOT_SINK, yaw, width * 0.5 * (0.75 + a * 0.5), height * (0.7 + b * 0.6), a)
        end
    end
    if #idx > 0 then
        nodraw.mesh.set("chunk_" .. key, MATERIAL, v, idx)
    end
    built[key] = true
end

-- Цвет травы как в аддоне: палитра из snake_grass_settings на карте (tipcolor, rootcolor,
-- maincolor, gradient, lightmapinfluence; по умолчанию — как cl_settings.lua). Как в
-- cl_chunks.lua: mix = t ^ (gradient * 1.35), тело — от корня к maincolor на нижней трети,
-- палитра авторская в sRGB → линейная. В режимах со светом — свет карты с силой
-- lightmapinfluence; в «3D Textured» — палитра без света, как текстуры рядом.
-- UV травинки: v = 1 у корня, 0 у кончика.
local DEFAULTS = { tip = { 0.16, 0.42, 0.06 }, root = { 0.05, 0.13, 0.03 }, gradient = 1.6, lightmap = 1.0 }
local look_key = nil

local function colour(value)
    if not value then return nil end
    local r, g, b = value:match("^%s*([%d%.%-]+)%s+([%d%.%-]+)%s+([%d%.%-]+)")
    if not r then return nil end
    return { tonumber(r) / 255, tonumber(g) / 255, tonumber(b) / 255 }
end

local function read_look()
    local look = { tip = DEFAULTS.tip, root = DEFAULTS.root, main = nil, gradient = DEFAULTS.gradient, lightmap = DEFAULTS.lightmap }
    local ents = nodraw.map.entities("snake_grass_settings")
    local e = ents and ents[1]
    if e then
        local k = nodraw.map.keys(e.id) or {}
        look.tip = colour(k.tipcolor) or look.tip
        look.root = colour(k.rootcolor) or look.root
        look.main = colour(k.maincolor)
        look.gradient = tonumber(k.gradient) or look.gradient
        look.lightmap = tonumber(k.lightmapinfluence) or look.lightmap
    end
    return look
end

local function vec(c)
    return string.format("vec3<f32>(%.5f, %.5f, %.5f)", c[1], c[2], c[3])
end

local function apply_look()
    local look = read_look()
    local main = look.main and vec(look.main) or vec(look.root)
    local key = vec(look.tip) .. vec(look.root) .. main .. look.gradient .. look.lightmap .. tostring(look.main ~= nil)
    if key == look_key then
        return
    end
    look_key = key
    nodraw.shader("screenspace_general:snake_grass_style_v8_boost_ps30", string.format([[
fn srgb_lin(c: vec3<f32>) -> vec3<f32> {
    return select(pow((c + 0.055) / 1.055, vec3<f32>(2.4)), c / 12.92, c <= vec3<f32>(0.04045));
}
fn plugin_main(i: VsOut) -> vec4<f32> {
    let t = clamp(1.0 - i.uv.y, 0.0, 1.0);
    let tip = %s;
    let root0 = %s;
    let body = %s;
    let has_body = %s;
    let root = select(root0, mix(root0, body, min(t / 0.3, 1.0)), has_body);
    let m = pow(t, %.4f * 1.35);
    var c = srgb_lin(mix(root, tip, m));
    let lit = cam.view.x > 1.5 && cam.view.x < 2.5;
    if (lit) {
        let l = map_light(i.world, vec3<f32>(0.0, 0.0, 1.0));
        c = c * (vec3<f32>(1.0 - %.4f) + %.4f * l);
    } else {
        let n = normalize(i.normal);
        c = c * (0.85 + 0.15 * abs(dot(n, cam.light_dir.xyz)));
    }
    let d = distance(i.world, cam.eye.xyz);
    let f = clamp((d - cam.fog.x) * cam.fog.y, 0.0, cam.fog.z);
    return vec4<f32>(mix(c, cam.fog_color.rgb, select(0.0, f, cam.view.x < 0.5)), 1.0);
}
]], vec(look.tip), vec(look.root), main, tostring(look.main ~= nil), look.gradient, look.lightmap, look.lightmap))
end

-- Трава плагина заменяет встроенное превью травы vbsp (иначе обе рисуются вместе).
nodraw.details_visible(not enabled)
apply_look()

-- Правка карты: только перечитать цвета (дёшево); трава пересобирается лишь при новой сборке.
nodraw.on("map", function()
    apply_look()
    if detail_revision ~= nodraw.map.details_revision() then
        collect()
    end
end)

nodraw.on("details", function()
    collect()
    nodraw.details_visible(not enabled)
end)

nodraw.on("frame", function()
    if not enabled then
        return
    end
    local cam = nodraw.camera()
    local fx, fy = cam.fx or 1, cam.fy or 0
    local flen = math.sqrt(fx * fx + fy * fy)
    if flen > 0.05 then
        fx, fy = fx / flen, fy / flen
    elseif cam.yaw then
        fx, fy = math.cos(cam.yaw), math.sin(cam.yaw)
    end

    local todo = {}
    for key in pairs(buckets) do
        local cx, cy = key:match("(-?%d+):(-?%d+)")
        local mx, my = (tonumber(cx) + 0.5) * CHUNK, (tonumber(cy) + 0.5) * CHUNK
        local dx = mx - cam.x
        local dy = my - cam.y
        local d = math.sqrt(dx * dx + dy * dy)

        -- Фрустум-куллинг: конус видимости перед камерой (с запасом для размера чанка 512).
        -- Чанки прямо под ногами (d < 450) видны всегда, чтобы трава не моргала при взгляде вниз.
        local in_cone = true
        local culled_behind = false
        if d >= 450 and d > 0 then
            local dot = (dx / d) * fx + (dy / d) * fy
            -- dot > -0.1 (~95° полуугол): в секторе взгляда, можно строить
            in_cone = (dot > -0.1)
            -- dot < -0.35 (> 110° угол): строго позади камеры, выгружать
            culled_behind = (dot < -0.35)
        end

        if d < RADIUS and in_cone and not built[key] then
            todo[#todo + 1] = { key, d }
        elseif built[key] and (d > RADIUS * 1.15 or culled_behind) then
            nodraw.mesh.clear("chunk_" .. key)
            built[key] = nil
        end
    end
    table.sort(todo, function(p, q) return p[2] < q[2] end)
    for i = 1, math.min(PER_FRAME, #todo) do
        build(todo[i][1])
    end
end)

nodraw.on("setting", function(id, value)
    if id == "enabled" then
        enabled = value
        if not enabled then
            clear_all()
        end
        nodraw.details_visible(not enabled)
        nodraw.status(enabled and "grass on" or "grass off")
    elseif id == "density" then
        density = value
        clear_all()
        nodraw.status("grass density " .. (densities[density] or 6) .. " blades per point")
    elseif id == "radius" then
        RADIUS = value
    elseif id == "spread" then
        SPREAD = value
        clear_all()
    end
end)
