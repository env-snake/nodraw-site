﻿NoDraw — редактор карт для Garry's Mod (Source 1)
=================================================

Как запустить
-------------
1. Распакуйте архив в любую папку (например, D:\NoDraw). Папки icons и plugins
   должны лежать рядом с NoDraw.exe — без них не будет иконок и плагинов.
2. Запустите NoDraw.exe. Установка не нужна.

Где указать Garry's Mod
-----------------------
NoDraw сам ищет Garry's Mod во всех библиотеках Steam этого компьютера
(по реестру Steam и steamapps\libraryfolders.vdf). Если не нашёл — при запуске
появится окно «Garry's Mod not found»: нажмите «Choose the folder…» и укажите папку
GarrysMod (обычно ...\steamapps\common\GarrysMod).
Поменять потом: меню Settings → Game Folder…

Компиляторы и FGD берутся из конфига Hammer++ / Hammer этой игры
(GarrysMod\bin\win64\hammerplusplus или GarrysMod\bin). Без Hammer++ свойства
энтити будут без FGD-описаний, а сборка карты — без компиляторов.

Карту открыть: File → Open (Ctrl+O) или перетащить .vmf на окно.
Настройки NoDraw хранятся в %APPDATA%\NoDraw (удалите папку, чтобы сбросить).
