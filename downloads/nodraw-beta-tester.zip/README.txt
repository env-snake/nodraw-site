﻿NoDraw — Level Editor for Source Engine & Garry's Mod
======================================================
Build: 2026-11-03 (Closed Beta)

How to launch:
1. Unpack the archive into any folder (e.g. D:\NoDraw).
2. The 'icons' and 'plugins' folders must stay next to NoDraw.exe.
3. Launch NoDraw.exe. No installation required.

Game Folder:
NoDraw automatically searches for Garry's Mod and Source SDK games in your
Steam libraries (steamapps\libraryfolders.vdf).
To change the game path manually: menu Settings -> Game Folder...

Map formats:
Open map: File -> Open (Ctrl+O) or drag-and-drop a .vmf file onto the window.
